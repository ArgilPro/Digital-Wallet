package com.example.rapidjava.stripeConnect;

import com.example.rapidjava.model.CustomerModel;
import com.example.rapidjava.model.Result;

import io.reactivex.Observable;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Query;
import retrofit2.http.Url;

public interface StripeServices {

    @Headers({
            "Content-Type:application/x-www-form-urlencoded",
            "Authorization:Bearer sk_test_51LIiuRHZorkf9EZn4xAynVAcZc1LwI0FiSUH9W0nuoCqenwFE5HHe8SUgX5tWGWIRPG01kfjw3iWT9JmMnuCjkK800F7DK9kFs"
    })
    @FormUrlEncoded
    @POST("customers")
    Observable<CustomerModel> createCustomer(
            @Field("email") String email,
            @Field("editText") String editText
    );



    @Headers({
            "Authorization:Bearer sk_test_51LIiuRHZorkf9EZn4xAynVAcZc1LwI0FiSUH9W0nuoCqenwFE5HHe8SUgX5tWGWIRPG01kfjw3iWT9JmMnuCjkK800F7DK9kFs"
    })
    @FormUrlEncoded
    @GET
    Observable<Result> getCard(
            @Url String url,
            @Query("type") String type  //define param name
    );
}
