package com.example.rapidjava.adapter;

import android.content.Context;
import android.os.StrictMode;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.rapidjava.Mijn_kaarten;
import com.example.rapidjava.R;
import com.example.rapidjava.model.Card;
import com.example.rapidjava.model.Dutam;
import com.stripe.Stripe;
import com.stripe.exception.StripeException;
import com.stripe.model.PaymentIntent;
import com.stripe.model.PaymentMethod;
import com.stripe.param.PaymentIntentCreateParams;

import java.util.List;

public class CardAdapter extends RecyclerView.Adapter<CardAdapter.ViewHolder> {

    Context context;

    public CardAdapter(Context context) {
        this.context = context;
    }

    List<Dutam> cardList;
    boolean Pay;
    int amount;

    public CardAdapter(Mijn_kaarten mijn_kaarten, List<Dutam> cardList, boolean pay, int amount) {
        this.cardList = cardList;
        this.Pay= pay;
        this.amount= amount;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.card_item,parent,false)) ;
    }

    @Override
    public void onBindViewHolder(@NonNull CardAdapter.ViewHolder holder, int position) {
        holder.brand.setText(cardList.get(position).getCard().getBrand());
        //**** is to make it look better
        holder.lastDigit.setText("**** **** ****" +cardList.get(position).getCard().getLast4());

        //add on click here
        if(Pay)
        {
            holder.deleteBtn.setVisibility(View.GONE);
            String customerId= "cus_Mc7ZSR4MPhtAXi";
            double total=17.50*100;//stripe doesn't take decimal so multiply by 100



            //add payment when we click on the card
            holder.PayLayout.setOnClickListener(view -> {
                //first we need to call stripe config
                Stripe.apiKey = "sk_test_51LIiuRHZorkf9EZn4xAynVAcZc1LwI0FiSUH9W0nuoCqenwFE5HHe8SUgX5tWGWIRPG01kfjw3iWT9JmMnuCjkK800F7DK9kFs";
                StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                StrictMode.setThreadPolicy(policy);

                PaymentIntentCreateParams.Shipping.Address address=
                PaymentIntentCreateParams.Shipping.Address.builder()
                        .setLine1("s10 thousand 31")
                        .setPostalCode("98140")
                        .setCity("Paramaribo")
                        .setState("Parbo")
                        .setCountry("Suriname")
                        .build();

                PaymentIntentCreateParams.Shipping shippingDetail=
                PaymentIntentCreateParams.Shipping.builder()
                        .setName("RapidPay")
                        .setAddress(address).build();



                PaymentIntentCreateParams payIntentPara= PaymentIntentCreateParams.builder()
                        .setCurrency("srd")
                        .setShipping(shippingDetail)//to make the payment possible we need address
                        .setAmount((long)total)
                        .setCustomer(customerId)
                        .setPaymentMethod(cardList.get(position).getId())
                        .addPaymentMethodType("card")
                        .setDescription("betaling voor testen")
                        .setConfirm(true)
                        .setOffSession(true)
                        .build();

                //now we make a payment
                try{
                    PaymentIntent payment=PaymentIntent.create(payIntentPara);
                    System.out.println("Betaling Succesvol ID"+payment.getId());
                }catch(StripeException e){
                    System.out.println("error" +e.getMessage());

                }
            });
        }else {
            holder.deleteBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    //we need card id here in our card list
                    //for card id we need some changes in our card list

                    //here we get the card id we want to delete

                    System.out.println(cardList.get(holder.getAbsoluteAdapterPosition()).getId());
                    //now add delete card
                    //if there are multiple cards one can be deleted

                    try {
                        //first add stripe key
                        Stripe.apiKey = "sk_test_51LIiuRHZorkf9EZn4xAynVAcZc1LwI0FiSUH9W0nuoCqenwFE5HHe8SUgX5tWGWIRPG01kfjw3iWT9JmMnuCjkK800F7DK9kFs";
                        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                        StrictMode.setThreadPolicy(policy);

                        //second two lines is for setting the thread policy

                        PaymentMethod paymentMethod = null;
                        //create one payment method object
                        //retrieve payment method by id and delete it

                        paymentMethod = PaymentMethod.retrieve(cardList.get(holder.getAbsoluteAdapterPosition()).getId());
                        //now delete it
                        PaymentMethod updatePayment = paymentMethod.detach();
                        //use detach method to delete
                        cardList.remove(holder.getAbsoluteAdapterPosition());
                        //update ui by notify
                        notifyDataSetChanged();
                    } catch (Exception e) {

                    }
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return cardList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        //first add delete button icon
        LinearLayout PayLayout;
        TextView brand,lastDigit,deleteBtn;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            brand=(itemView).findViewById(R.id.cardBrand);
            lastDigit=(itemView).findViewById(R.id.cardNumber);
            deleteBtn=(itemView).findViewById(R.id.delete);

            //add on click listener
        }
    }
}
